

#include<stdexcept>
using namespace std ;
namespace ariel
{
    string snowman  (int num ) ;
 
} // namespace ariel
